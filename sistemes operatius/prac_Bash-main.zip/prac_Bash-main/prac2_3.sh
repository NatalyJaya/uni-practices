#!/bin/bash
# ----------------------------------------------------------------------
# PRA2: Guions bash
# Codi font: <prac2_3>
#
# Yhislaine Nataly, Jaya Salazar
# Aleix Rosinach Olivart
# ----------------------------------------------------------------------

# Funció per calcular el màxim
maximo() {
    local max=$1 #max l'assignem al primer parametre que sera amb el que començarem a fer la comparació per trobar el màxim
    shift
    while [ $# -ne 0 ]; do # mentre de el num. d'arguments no és igual a 0 fem..
        if [ "$1" -gt "$max" ]; then  # si el valor del argument és més gran que el valor 'mayor' -> reassignem quin es el parametre màxim
            max=$1
        fi
        shift #desplaçem un parametre  a la esquerra $1 <--$2 , $2 <--$3 ...
    done
    echo $max # mostrem el valor màxim
}

# Funció per calcular el mínim (mateixa estructura que el maximo)
minimo() {
    local menor=$1
    shift
    while [ $# -ne 0 ]; do
        if [ "$1" -lt "$menor" ]; then # el valor del argument es més petit que el valor de menor
            menor=$1
        fi
        shift
    done
    echo $menor
}

# Funció per determinar si un número és primer
es_primo() {
    if [ $1 -le 1 ]; then #si el primer parametre es més petit o igual que 1
        return 1 # retornem el 1 (fals)
    fi

    for ((i=2; i*i<=$1; i++)); do  # for per provar divisors entre 2 i l'arrel quadrada del número (i*i <= $1)
        if [ $(($1 % $i)) -eq 0 ]; then # Per cada valor de i, comprova si $1 és divisible per i (és a dir, el residu de $1 % $i és 0)
            return 1 #Si ho és, retorna 1 (fals).
        fi
    done
    return 0 # Si cap divisor fins a l'arrel quadrada no divideix exactament el número, retorna 0 (cert), indicant que és primer.
}

# Funció per trobar els números primers de la seqüència
primos() {
    local primos="" #primos per emmagatzemar els números primers trobats
    for num in "$@"; do  #Itera per cada número en la llista d'arguments ("$@": tots els arguments)
        if es_primo $num; then #Per a cada número, crida la funció es_primo. Si el número és primer (retorna 0), l'afegeix a la llista primos
            primos="$primos $num"
        fi
    done
    echo $primos
}

# Verificar si hi ha almenys dos arguments
if [ $# -lt 2 ]; then #si el numero de arguments($#) es mes petit que dos imprim un missatge de error
    echo "Us: $0 <numero 1> <numero2> [... <numero N>]"
    exit 1
fi

# Mostrar el menú i processar l'opció
while true; do
    echo "M E N Ú"
    echo "--------"
    echo "X: Màxim"
    echo "N: Mínim"
    echo "P: Primers"
    read -p "Tria una opcio: " opcio #read per llegir l'opció introduïda per l'usuari i la guarda a la variable opcio

    case ${opcio,,} in #Converteix l’entrada a minúscules amb ${opcio,,} per assegurar-se que el programa reconeix tant majúscules com minúscules 
        x)
            echo "Maxim de [$*] : $(maximo "$@")" #Si l’usuari tria x o X, crida la funció maximo passant-li tots els arguments ("$@") i mostra el resultat
            break
            ;;
        n)
            echo "Minim de [$*] : $(minimo "$@")" #similar al anterior, però crida la funció minimo per calcular el valor mínim
            break
            ;;
        p)
            echo "Nombres primers de [$*] : $(primos "$@")" #Si l’usuari tria p o P, crida la funció primos per identificar els nombres primers i mostra el resultat
            break
            ;;
        *)
            echo "Opcio '$opcio' no valida" #Si l’usuari introdueix una opció que no sigui x, n o p, el programa mostra un missatge indicant que és invàlid i surt del menú
            break
            ;;
    esac
done



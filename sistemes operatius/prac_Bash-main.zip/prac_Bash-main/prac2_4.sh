#!/bin/bash
# ----------------------------------------------------------------------
# PRA2: Guions bash
# Codi font: <prac2_4>
#
# Yhislaine Nataly, Jaya Salazar
# Aleix, Rosinach Olivart
# ---------------------------------------------------------------------- 

#!/bin/bash

# Funció per comprovar si un usuari està connectat i mostrar els seus processos
comprova_usuari() {
  local usuari=$1
  if who | grep -qw "$usuari"; then # Forma 1 de substitució de comandes
    # Comptem el nombre de processos de l'usuari
    processos=$(ps -u "$usuari" --no-headers | wc -l)
    echo "$usuari connectat actualment amb $processos processos en execució"
  else
    echo "$usuari NO connectat actualment"
  fi
}

# Si no es passen paràmetres
if [ $# -eq 0 ]; then # Format 1 de comparació
  # Obtenim tots els usuaris del sistema des del fitxer /etc/passwd
  usuaris=$(cut -d: -f1 /etc/passwd) # Forma 2 de substitució de comandes
  for usuari in $usuaris; do
    comprova_usuari "$usuari"
  done
else
  # Es comprova cadascun dels usuaris passats com a paràmetres
  for usuari in "$@"; do
    if [[ -n $usuari ]]; then # Format 2 de comparació
      comprova_usuari "$usuari"
    fi
  done
fi

#!/bin/bash
# ----------------------------------------------------------------------
# PRA2: Guions bash
# Codi font: <prac2_2.sh>
#
# Yhislaine Nataly, Jaya Salazar
# Aleix, Rosinach Olivart
# ---------------------------------------------------------------------- 
#!/bin/bash

# Comprovació del nombre de paràmetres
if [ $# -ne 2 ]; then
    echo "$0 suma els dos nombres passats com a parametres"
    echo "Ús: $0 <nombre1> <nombre2>"
    exit 1
fi

# Operació de suma
echo "$1 + $2 = $(expr $1 + $2)"

# Solucions alternatives
echo "$1 + $2 = $(($1 + $2))"
let sum=$1+$2
echo "$1 + $2 = $sum"

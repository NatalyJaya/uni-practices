module Main where 
sumOfSquares :: [Int] -> Int
sumOfSquares[] = 0
sumOfSquares (x:xs) = x^2 + sumOfSquares xs


main = print (sumOfSquares [1, 2, 3])  

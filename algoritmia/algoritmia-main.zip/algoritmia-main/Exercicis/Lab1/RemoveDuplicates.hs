removeDuplicates :: [Int] -> [Int]
removeDuplicates [] = []
removeDuplicates[x] = [x]
removeDuplicates (x:xs)
    | x == primer xs = removeDuplicates xs  --esta duplicat
    | otherwise = x : removeDuplicates xs   --concatenem el que no es un duplicat

primer (y:ys)=y

main :: IO ()
main = print (removeDuplicates [1,2,2,3,4,4,5])
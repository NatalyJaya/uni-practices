module Main where

splitList ::  [Int] -> ([Int], [Int])
--


splitList xs = 
    let halfLength = length xs `div` 2  -- Calculamos la longitud de la mitad
        firstHalf = take halfLength xs   -- Agarro la primera parte
        secondHalf = drop halfLength xs  -- Agarro la segunda aprte
    in (firstHalf, secondHalf)  -- tupla de ambas partes

--
main :: IO ()
main = print(splitList [1, 2, 3, 4, 5])

-- Checks if the list is palindrome
isPalindromeCheck [] = True
isPalindromeCheck (x:xs)
    | xs == [] = True   
    -- A single element is palindrome
    | x == last xs = isPalindromeCheck (init xs) 
    -- We use init xs to remove the last element
    | otherwise = False
--fin
main :: IO()
main = do
  print (isPalindromeCheck[1, 2, 3, 2, 1])  -- True
  print (isPalindromeCheck[1, 2, 3, 4, 5])  -- False
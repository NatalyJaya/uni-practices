--correccio del profe
filtrarParells :: [Int]-> [Int]
filtrarParells[] = []
filtrarParells(x:xs)
    | esParell x = filtrarParells xs
    |otherwise = x : filtrarParells xs
esParell :: Int -> Bool

esParell x =
    if mod x 2 == 0 then True
    else False


main :: IO ()
main = print (filtrarParells [1, 2, 3, 4, 5, 6, 7, 8, 9])

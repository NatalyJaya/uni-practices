runLengthEncode [] = []
runLengthEncode (x:xs) = (x, count (x:xs)) : runLengthEncode (removeFirstConsecutives (x:xs))

count [] = 0
count [x] = 1
count (x:y:xs)
    | x == y = 1 + count (y:xs)
    | otherwise = 1

removeFirstConsecutives [] = []
removeFirstConsecutives [x] = []
removeFirstConsecutives (x:y:xs)
    | x == y = removeFirstConsecutives (y:xs)
    | otherwise = (y:xs)

main = print (runLengthEncode "aaaabbbcca")

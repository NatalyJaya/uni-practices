module Main where

-- Checks if a number is prime
isPrime :: Int -> Bool
isPrime a = checkPrime a (a - 1)

checkPrime :: Int -> Int -> Bool
checkPrime a b
    | a < 2 = False
    | b < 2 = True
    | a `mod` b == 0 = False
    | otherwise = checkPrime a (b - 1)

-- Finds the primes in a list
findPrimes :: [Int] -> [Int]
findPrimes [] = []  -- Base case: empty list
findPrimes (x:xs)
    | isPrime x = x : findPrimes xs  -- Keep primes
    | otherwise = findPrimes xs      -- Discard non-primes

-- Main function
main :: IO ()
main = print (findPrimes [1, 2, 3, 4, 5, 6, 7, 8, 9])

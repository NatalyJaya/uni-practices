-- HEAD
myHead :: [Int] -> Int
myHead [] = error "Lista vacía"
myHead (x:xs) = x

-- Alternativa con `!!`
myHeadAlt :: [Int] -> Int
myHeadAlt xs = xs !! 0

-- TAIL
myTail :: [Int] -> [Int]
myTail [] = []
myTail (x:xs) = xs

-- TAKE
myTake :: Int -> [Int] -> [Int]
myTake 0 xs = []
myTake _ [] = []
myTake x (y:xs) = [y] ++ myTake (x-1) xs

-- DROP
myDrop :: Int -> [Int] -> [Int]
myDrop 0 xs = xs
myDrop _ [] = []
myDrop x (y:xs) = myDrop (x-1) xs

-- LENGTH
myLenght :: [Int] -> Int
myLenght [] = 0
myLenght (x:xs) = 1 + myLenght xs

-- SUM
mySum :: [Int] -> Int
mySum [] = 0
mySum (x:xs) = x + mySum xs

-- PRODUCT
myProduct :: [Int] -> Int
myProduct [] = 1
myProduct (x:xs) = x * myProduct xs

-- REVERSE
myReverse :: [Int] -> [Int]
myReverse [] = []
myReverse (x:xs) = myReverse xs ++ [x]

-- LAST
myLast :: [Int] -> Int
myLast [] = error "Lista vacía"
myLast [x] = x
myLast (x:xs) = myLast xs

-- INIT (Devuelve todos los elementos excepto el último)
myInit :: [Int] -> [Int]
myInit [] = error "Lista vacía"
myInit [x] = []
myInit (x:xs) = [x] ++ myInit xs

-- MAIN para probar las funciones
main :: IO ()
main = do
    print (myHead [1, 2, 3, 4])       -- 1
    print (myHeadAlt [1, 2, 3, 4])    -- 1
    print (myTail [1, 2, 3, 4])       -- [2, 3, 4]
    print (myTake 2 [1, 2, 3, 4])     -- [1, 2]
    print (myDrop 2 [1, 2, 3, 4])     -- [3, 4]
    print (myLenght [1, 2, 3, 4])     -- 4
    print (mySum [1, 2, 3, 4])        -- 10
    print (myProduct [1, 2, 3, 4])    -- 24
    print (myReverse [1, 2, 3, 4])    -- [4, 3, 2, 1]
    print (myLast [1, 2, 3, 4])       -- 4
    print (myInit [1, 2, 3, 4])       -- [1, 2, 3]

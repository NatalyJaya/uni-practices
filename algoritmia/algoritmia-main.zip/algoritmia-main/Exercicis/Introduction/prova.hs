module Main where

tupla :: (Int, Int, Int)
tupla = (1, 2, 3)
--
main :: IO ()
main = print tupla